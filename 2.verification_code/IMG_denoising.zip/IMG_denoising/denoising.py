#coding:utf-8
import Image
import pytesseract
import ImageEnhance

img = Image.open('11.png')
img = img.convert('RGBA')
img = img.convert('L')
img.save('end_9.png')

sharpness = ImageEnhance.Sharpness(img)#锐利化
img = sharpness.enhance(7.0)
img.save('end_0.png')
#img = ImageEnhance.Color(img) #变黑白
#img = img.enhance(0)
img.save('end_1.png')
img = ImageEnhance.Brightness(img) # 提高亮度
img = img.enhance(3)
img.save('end_2.png')
img = ImageEnhance.Contrast(img) # 高对比
img = img.enhance(8)
img.save('end_3.png')
#img = ImageEnhance.Color(img)
#img = img.convert('L')

#coding:utf-8
import sys,os
from PIL import Image,ImageDraw

#二值数组
t2val = {}
def twoValue(image,G):
    for y in xrange(0,image.size[1]):
        for x in xrange(0,image.size[0]):
            g = image.getpixel((x,y))
            if g > G:
                t2val[(x,y)] = 1
            else:
                t2val[(x,y)] = 0

# 降噪
# 根据一个点A的RGB值，与周围的8个点的RBG值比较，设定一个值N（0 <N <8），当A的RGB值与周围8个点的RGB相等数小于N时，此点为噪点
# G: Integer 图像二值化阀值
# N: Integer 降噪率 0 <N <8
# Z: Integer 降噪次数
# 输出
#  0：降噪成功
#  1：降噪失败
def clearNoise(image,N,Z):

    for i in xrange(0,Z):
        t2val[(0,0)] = 1
        t2val[(image.size[0] - 1,image.size[1] - 1)] = 1

        for x in xrange(1,image.size[0] - 1):
            for y in xrange(1,image.size[1] - 1):
                nearDots = 0
                L = t2val[(x,y)]
                if L == t2val[(x - 1,y - 1)]:
                    nearDots += 1
                if L == t2val[(x - 1,y)]:
                    nearDots += 1
                if L == t2val[(x- 1,y + 1)]:
                    nearDots += 1
                if L == t2val[(x,y - 1)]:
                    nearDots += 1
                if L == t2val[(x,y + 1)]:
                    nearDots += 1
                if L == t2val[(x + 1,y - 1)]:
                    nearDots += 1
                if L == t2val[(x + 1,y)]:
                    nearDots += 1
                if L == t2val[(x + 1,y + 1)]:
                    nearDots += 1

                if nearDots < N:
                    t2val[(x,y)] = 1

def saveImage(filename,size):
    image = Image.new("1",size)
    draw = ImageDraw.Draw(image)

    for x in xrange(0,size[0]):
        for y in xrange(0,size[1]):
            draw.point((x,y),t2val[(x,y)])

    image.save(filename)

image = Image.open("d:/1.jpg").convert("L")
twoValue(image,100)
clearNoise(image,4,1)
saveImage("./5.jpg",image.size)
